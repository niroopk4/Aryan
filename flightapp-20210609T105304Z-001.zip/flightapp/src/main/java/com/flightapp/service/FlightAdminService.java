package com.flightapp.service;

import com.flightapp.domain.Admin;
import com.flightapp.domain.User;
import com.flightapp.exception.FlightAdminException;

public interface FlightAdminService {

	Admin adminLogin(Admin admin) throws FlightAdminException;

	User userSignUp(User user) throws FlightAdminException;

	User userSignIn(String email, String password) throws FlightAdminException;

}
