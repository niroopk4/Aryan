package com.flightapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.flightapp.domain.Airline;
import com.flightapp.domain.AirlineSchedules;
import com.flightapp.exception.FlightAdminException;
import com.flightapp.repository.AirlineRepository;
import com.flightapp.repository.AirlineScheduleRepository;

@Service
public class ManageAirlineServiceImpl implements ManageAirlineService {
	@Autowired
	private AirlineRepository airlineRepo;
	@Autowired
	private AirlineScheduleRepository airlineScheduleRepo;
	
	
	@Override
	public Airline addAirline(Airline airline) throws FlightAdminException {
		try {

			Assert.notNull(airline, "Data cannot be null");
			return airlineRepo.save(airline);
			
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}

	}

	@Override
	public AirlineSchedules addAirlineSchedule(AirlineSchedules airlineSchedule) throws FlightAdminException {
		try {

			Assert.notNull(airlineSchedule, "Data cannot be null");
			return airlineScheduleRepo.save(airlineSchedule);
			
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}
	}

	@Override
	public List<Airline> getAirlines() {

		return airlineRepo.findAll();
		
	}

	@Override
	public List<AirlineSchedules> getAirlineSchedules(int flightNumber, String instrumentUsed) throws FlightAdminException {

		try {
			Assert.notNull(flightNumber, "Flight Number cannot be null");
			Assert.hasText(instrumentUsed, "Instrument used cannot be null");
			return airlineScheduleRepo.findByFlightNumberAndInstrumentUsed(flightNumber, instrumentUsed);
		} catch (Exception e) {
			throw new FlightAdminException(e.getMessage());
		}
	}

}
