package com.flightapp.service;

import java.util.List;

import com.flightapp.domain.Airline;
import com.flightapp.domain.AirlineSchedules;
import com.flightapp.exception.FlightAdminException;

public interface ManageAirlineService {

	Airline addAirline(Airline airline) throws FlightAdminException;

	AirlineSchedules addAirlineSchedule(AirlineSchedules airlineSchedule) throws FlightAdminException;

	List<Airline> getAirlines();

	List<AirlineSchedules> getAirlineSchedules(int flightNumber, String instrumentUsed) throws FlightAdminException;

}
