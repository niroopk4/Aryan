package com.flightapp.exception;

public class FlightAdminException extends Exception {

	public FlightAdminException() {}
	public FlightAdminException(Exception e) {
		super(e);
	}
	public FlightAdminException(String s) {
		super(s);
	}
	public FlightAdminException(String s, Exception e) {
		super(s, e);
	}
}
