package com.flightapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flightapp.domain.Admin;
import com.flightapp.domain.Airline;
import com.flightapp.domain.AirlineSchedules;
import com.flightapp.exception.FlightAdminException;
import com.flightapp.service.ManageAirlineService;

@RestController
@RequestMapping("api/v1.0/flight/airline")
@CrossOrigin
public class AirlineController {

	@Autowired
	private ManageAirlineService manageAirlineService;
	
	@PostMapping("/register")
	public Airline addAirline(@RequestBody Airline airline) throws FlightAdminException {
		System.err.println("inside addAirlineSchedule: " + airline);
		return manageAirlineService.addAirline(airline);
	}
	
	@PostMapping("/inventory/add")
	public AirlineSchedules addAirlineSchedule(@RequestBody AirlineSchedules airlineSchedule) throws FlightAdminException {
		System.err.println("inside addAirlineSchedule: " + airlineSchedule);
		return manageAirlineService.addAirlineSchedule(airlineSchedule);
	}
	
	@GetMapping("/getairlines")
	public List<Airline> getAirlines() throws FlightAdminException {
		System.err.println("inside getAirlines: ");
		return manageAirlineService.getAirlines();
	}
	
	@GetMapping("/getairlineSchedules/{flightNumber}/{instrumentUsed}")
	public List<AirlineSchedules> getAirlineSchedules(@PathVariable int flightNumber, @PathVariable String instrumentUsed) throws FlightAdminException {
		System.err.println("inside getAirlineSchedules: ");
		return manageAirlineService.getAirlineSchedules(flightNumber, instrumentUsed);
	}
	
}
