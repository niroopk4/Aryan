package com.flightapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flightapp.domain.Admin;
import com.flightapp.domain.User;
import com.flightapp.exception.FlightAdminException;
import com.flightapp.service.FlightAdminService;

@RestController
@RequestMapping("api/v1.0/flight/admin")
@CrossOrigin
public class FlightAdminController {

		@Autowired
		private FlightAdminService flightAdminService;
	
		@PostMapping("/login")
		public Admin adminLogin(@RequestBody Admin admin) throws FlightAdminException {
			System.err.println("inside admin login" + admin);
			return flightAdminService.adminLogin(admin);
		}
		
		@PostMapping("/usersignup")
		public User userSignUp(@RequestBody User user) throws FlightAdminException {
			System.err.println("inside user signup" + user);
			return flightAdminService.userSignUp(user);
		}
		
		@GetMapping("/usersignin/{email}/{password}")
		public User userSignIn(@PathVariable String email, @PathVariable String password) throws FlightAdminException {
			System.err.println("inside user signin" + email + password);
			return flightAdminService.userSignIn(email, password);

		}
		
		
}
