package com.flightapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flightapp.domain.AirlineSchedules;

public interface AirlineScheduleRepository extends JpaRepository<AirlineSchedules, Integer>{

	List<AirlineSchedules> findByFlightNumberAndInstrumentUsed(int flightNumber, String instrumentUsed);

}
