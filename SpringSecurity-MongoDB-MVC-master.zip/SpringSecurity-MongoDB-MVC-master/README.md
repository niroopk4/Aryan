SpringSecurity-MongoDB-MVC
==========================

In this example you can see the next topics

- SpringData With MongoDb Integration
- Spring MVC to manage navigation
- Spring Security with Custom user detais service to asign roles 

